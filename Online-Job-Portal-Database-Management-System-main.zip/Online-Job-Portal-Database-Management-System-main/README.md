# Online-Job-Portal-Database-Management-System
This project proposes the creation of an integrated online job portal that leverages the capabilities of database management systems to provide a comprehensive solution for job seekers, employers, and administrators. 
For frontend I have used HTML, CSS and JavaScript and For backend I have used PHP, MySql as database and apache usingFlask for the serverin localhost.
The primary objectives of this project include:
-1.	Efficient Job Search
-2.	Streamlined Application Process
-3.	Comprehensive Employer Dashboard
-4.	Administrative Control and Monitoring
